#Permissions installer

#chown nobody:nogroup -R /var/www/html/G13_VersionPreliminar
#chmod -R 777 /var/www/html/G13_VersionPreliminar
chown nobody:nogroup -R /var/www/html/ActiFit
chmod -R 777 /var/www/html/ActiFit
exit
