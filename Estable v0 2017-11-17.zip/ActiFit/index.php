<?php
//Application start file

	//header('Location:./views/home.php');
	//header('Location:./views/home.php');
	header('Location:./views/index.php');
?>
