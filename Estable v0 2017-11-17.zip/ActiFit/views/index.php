<?php
//Application start file

include '../views/log_in.php';

	new LogIn('');

?>
