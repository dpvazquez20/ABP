|									|
|				DEFAULT USERS				|		
|									|
|-----------------------------------------------------------------------|
|	USERNAME	|	PASSWORD	|	TYPE		|
|-----------------------|-----------------------|-----------------------|
|	admin		|	admin		| Administrador 	|						|
|	secretario	|	secretario	|	Secretario	|
|	entrenador	|	entrenador	|	Entrenador	|
|	deportista	|	deportista	|	Deportista	|
-------------------------------------------------------------------------